using UnityEngine;
using AssetBundles;

public class Example1 : MonoBehaviour
{
    private AssetBundleManager abm;

    private void Start()
    {
        Caching.ClearCache();

        abm = new AssetBundleManager();
        abm.Initialize("http://icoder.dothome.co.kr/AssetBundles")
           .UseStreamingAssets()
           .UseSimulation()
           .Load(success =>
            {
                if (success)
                {
                    abm.LoadBundle("prefabs", bundle =>
                    {
                        if (bundle != null)
                        {
                            Instantiate(bundle.LoadAsset<GameObject>("button"), transform);
                            abm.UnloadBundle(bundle);
                        }
                    });
                }
            });
    }

    private void OnDestroy()
    {
        abm?.Dispose();
    }
}