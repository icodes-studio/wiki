using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using AssetBundles;

public class Example2 : MonoBehaviour
{
    private AssetBundleManager abm;

    private IEnumerator Start()
    {
        Caching.ClearCache();

        abm = new AssetBundleManager();
        var loadAsync = abm
            .Initialize("http://icoder.dothome.co.kr/AssetBundles")
            .UseStreamingAssets()
            .UseSimulation()
            .Load();

        yield return loadAsync;
        if (loadAsync.Success)
        {
            var loadBundleAsync = abm.LoadBundle("scenes");
            yield return loadBundleAsync;
            if (loadBundleAsync.Success)
            {
                yield return SceneManager.LoadSceneAsync("test", LoadSceneMode.Additive);
                abm.UnloadBundle(loadBundleAsync.AssetBundle);
            }
        }
    }

    private void OnDestroy()
    {
        abm?.Dispose();
    }
}
