using UnityEngine;
using UnityEngine.UI;
using AssetBundles;

public class Example3 : MonoBehaviour
{
    private AssetBundleManager abm;

    private async void Start()
    {
        Caching.ClearCache();

        abm = new AssetBundleManager();
        abm.Initialize("http://icoder.dothome.co.kr/AssetBundles")
           .UseStreamingAssets()
           .UseSimulation()
           .Load();

        var loadAsync = abm.LoadAsync();
        await loadAsync;
        if (loadAsync.Result)
        {
            var loadBundleAsync = abm.LoadBundleAsync("sprites");
            await loadBundleAsync;
            if (loadBundleAsync.Result != null)
            {
                var image = GetComponentInChildren<Image>();
                //image.sprite = loadBundleAsync.Result.LoadAsset<Sprite>("sprite");
                //image.sprite = loadBundleAsync.Result.LoadAsset<Sprite>("assets/sprites/sprite.png");
                image.sprite = loadBundleAsync.Result.LoadAsset<Sprite>("assets/sprites/test/sprite.png");
                abm.UnloadBundle(loadBundleAsync.Result);
            }
        }
    }

    private void OnDestroy()
    {
        abm?.Dispose();
    }
}