﻿using System;
using UnityEngine;
using System.Threading.Tasks;

namespace AssetBundles
{
    /// <summary>
    /// Simple AssetBundle management.
    /// A partial class implemented in relation to the task asynchronous interface
    /// </summary>
    public partial class AssetBundleManager : IDisposable
    {
        /// <summary>
        /// Load the platform(entry-point) manifest file.
        /// Downloads the AssetBundle manifest and prepares the system for bundle management.
        /// Uses the platform name as the manifest name.
        /// </summary>
        public Task<bool> LoadAsync()
        {
            return LoadAsync(platformName, true);
        }

        /// <summary>
        /// Load the platform(entry-point) manifest file.
        /// </summary>
        /// <param name="manifestName">The name of the manifest file to download.</param>
        /// <param name="refresh">Always try to download a new manifest even if one has already been cached.</param>
        public Task<bool> LoadAsync(string manifestName, bool refresh)
        {
            var completionSource = new TaskCompletionSource<bool>();
            Load(manifestName, refresh, result => completionSource.SetResult(result));
            return completionSource.Task;
        }

        /// <summary>
        /// Downloads an AssetBundle or returns a cached AssetBundle if it has already been downloaded.
        /// Remember to call UnloadBundle for every bundle you download once you are done with it.
        /// </summary>
        /// <param name="bundleName">Name of the bundle to download.</param>
        public Task<AssetBundle> LoadBundleAsync(string bundleName)
        {
            return LoadBundleAsync(bundleName, DownloadSettings.UseCacheIfAvailable);
        }

        /// <summary>
        /// Downloads an AssetBundle or returns a cached AssetBundle if it has already been downloaded.
        /// Remember to call UnloadBundle for every bundle you download once you are done with it.
        /// </summary>
        /// <param name="bundleName">Name of the bundle to download.</param>
        /// <param name="downloadSettings">
        ///     Tell the function to use a previously downloaded version of the bundle if available.
        ///     If the bundle is currently "active" (it has not been unloaded) then the active bundle will be used regardless of this setting.
        ///     If it's important that a new version is downloaded then be sure it isn't active.
        /// </param>
        public Task<AssetBundle> LoadBundleAsync(string bundleName, DownloadSettings downloadSettings)
        {
            var completionSource = new TaskCompletionSource<AssetBundle>();
            LoadBundle(bundleName, downloadSettings, bundle => completionSource.SetResult(bundle));
            return completionSource.Task;
        }
    }
}
