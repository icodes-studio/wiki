﻿using System.Collections;
using UnityEngine;

namespace AssetBundles
{
    /// <summary>
    /// Utility to run coroutine functions in the player
    /// </summary>
    class AssetBundleCoroutine : MonoBehaviour
    {
        private static AssetBundleCoroutine instance;

        public static AssetBundleCoroutine Instance
        {
            get
            {
                if (instance == null)
                    instance = CreateInstance();

                return instance;
            }
        }

        private static AssetBundleCoroutine CreateInstance()
        {
            var go = new GameObject(nameof(AssetBundleCoroutine));
            DontDestroyOnLoad(go);
            return go.AddComponent<AssetBundleCoroutine>();
        }

        public static void Coroutine(IEnumerator coroutine)
        {
            Instance.StartCoroutine(coroutine);
        }

        private void Awake()
        {
            if (instance != null)
            {
                DestroyImmediate(gameObject);
                return;
            }

            Application.runInBackground = true;
        }

        private void OnDestroy()
        {
            if (instance == this)
                instance = null;
        }
    }
}
