﻿#if UNITY_EDITOR
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace AssetBundles
{
    /// <summary>
    /// Utility to run coroutine functions in the editor
    /// </summary>
    class AssetBundleCoroutineEditor
    {
        private readonly Stack<IEnumerator> coroutines = new Stack<IEnumerator>();

        public static void Coroutine(IEnumerator coroutine)
        {
            new AssetBundleCoroutineEditor(coroutine).Start();
        }

        private AssetBundleCoroutineEditor(IEnumerator coroutine)
        {
            coroutines.Push(coroutine);
        }

        private void Start()
        {
            EditorApplication.update += Update;
        }

        private void Stop()
        {
            EditorApplication.update -= Update;
        }

        private void Update()
        {
            try
            {
                var current = coroutines.Peek();

                if (current.MoveNext() == false)
                {
                    coroutines.Pop();
                }
                else if (current.Current is IEnumerator)
                {
                    coroutines.Push((IEnumerator)current.Current);
                }
                else if (current.Current is AsyncOperation)
                {
                    var temp = (AsyncOperation)current.Current;
                    coroutines.Push(new AsyncToCustomYield(temp));
                }

                if (coroutines.Count == 0)
                {
                    Stop();
                }
            }
            catch (Exception)
            {
                coroutines.Clear();
                Stop();
                throw;
            }
        }

        class AsyncToCustomYield : CustomYieldInstruction
        {
            private AsyncOperation async;

            public AsyncToCustomYield(AsyncOperation async)
            {
                this.async = async;
            }

            public override bool keepWaiting
            {
                get { return async.isDone == false; }
            }
        }
    }
}
#endif