﻿using System;
using System.Collections;
using UnityEngine;

namespace AssetBundles
{
    /// <summary>
    /// When StreamingAsset's bundle is up to date, bundle should be retrieved from StreamingAssets
    /// 
    /// Detailed rules
    ///  #) There IS a manifest in the StreamingAssets folder
    ///  #) We ARE NOT trying to retrieve the remote manifest
    ///  #) The file exists in the StreamingAssets folder
    ///  #) One of:
    ///     - We ARE prioritizing StreamingAssets bundles over remote bundles
    ///     - The hash for the bundle in StreamingAssets matches the requested hash
    /// </summary>
    class AssetBundleDownloaderStreamingAsset : ICommandHandler<AssetBundleDownloadCommand>
    {
        private string manifestName;
        private string platformName;
        private string streamingAssetsPath;
        private PrioritizationStrategy priority;
        private ICommandHandler<AssetBundleDownloadCommand> downloader;
        private Action<IEnumerator> coroutine;

        /// <summary>
        /// Creates a new instance of the AssetBundleDownloaderStreamingAsset.
        /// </summary>
        public AssetBundleDownloaderStreamingAsset(
            string manifestName,
            string platformName,
            ICommandHandler<AssetBundleDownloadCommand> downloader,
            PrioritizationStrategy priority)
        {
            this.downloader = downloader;
            this.manifestName = manifestName;
            this.priority = priority;
            this.platformName = platformName;

#if UNITY_EDITOR
            if (Application.isPlaying == false)
                coroutine = AssetBundleCoroutineEditor.Coroutine;
            else
#endif
                coroutine = AssetBundleCoroutine.Coroutine;

            streamingAssetsPath = $"{Application.streamingAssetsPath}/{AssetBundleTools.AssetFolder}/{platformName}";

            var manifestPath = $"{streamingAssetsPath}/{platformName}";
            var manifestBundle = AssetBundle.LoadFromFile(manifestPath);

            if (manifestBundle == null)
            {
                Debug.LogWarning($"Unable to retrieve manifest file [{manifestPath}] from StreamingAssets, disabling StreamingAssetsBundleDownloadDecorator.");
            }
            else
            {
                Manifest = manifestBundle.LoadAsset<AssetBundleManifest>("assetbundlemanifest");
                manifestBundle.Unload(false);
            }
        }

        /// <summary>
        /// Begin handling of a AssetBundleDownloadCommand object.
        /// </summary>
        public void Handle(AssetBundleDownloadCommand command)
        {
            coroutine(OnHandle(command));
        }

        /// <summary>
        /// Begin download via the coroutine.
        /// </summary>
        private IEnumerator OnHandle(AssetBundleDownloadCommand command)
        {
            if (IsAvailableInStreamingAssets(command.BundleName, command.Hash))
            {
                var request = AssetBundle.LoadFromFileAsync(streamingAssetsPath + "/" + command.BundleName);
                yield return request;
                //while (request.isDone == false)
                //{
                //    Debug.Log($"Loading: {request.progress}");
                //    yield return null;
                //}

                if (request.assetBundle != null)
                {
                    command.OnComplete(request.assetBundle);
                    yield break;
                }

                Debug.LogWarning($"StreamingAssets download failed for bundle [{command.BundleName}], switching to standard download.");
            }

            downloader.Handle(command);
        }

        /// <summary>
        /// Returns whether the bundle should be retrieved from StreamingAssets or not.
        /// </summary>
        private bool IsAvailableInStreamingAssets(string bundleName, Hash128 hash)
        {
            // Rules for when a bundle should be retrieved from StreamingAssets
            //  #) There IS a manifest in the StreamingAssets folder
            //  #) We ARE NOT trying to retrieve the remote manifest
            //  #) The file exists in the StreamingAssets folder
            //  #) One of:
            //      - We ARE prioritizing StreamingAssets bundles over remote bundles
            //      - The hash for the bundle in StreamingAssets matches the requested hash

            if (Manifest == null)
            {
                Debug.Log("StreamingAssets manifest is null, using standard download.");
                return false;
            }

            if (bundleName == manifestName)
            {
                Debug.Log("Attempting to download manifest file, using standard download.");
                return false;
            }

            if (Manifest.GetAssetBundleHash(bundleName) != hash && priority != PrioritizationStrategy.StreamingAssets)
            {
                Debug.Log($"Hash for [{bundleName}] does not match the one in StreamingAssets, using standard download.");
                return false;
            }

            Debug.Log($"Using StreamingAssets for bundle [{bundleName}]");

            return true;
        }

        /// <summary>
        /// StreamingAssets's flatform's manifest
        /// </summary>
        public AssetBundleManifest Manifest
        {
            get; private set;
        }
    }
}
