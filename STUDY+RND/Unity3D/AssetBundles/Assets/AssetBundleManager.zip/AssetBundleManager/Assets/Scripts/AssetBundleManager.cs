using System;
using System.Text;
using System.Collections.Generic;
using UnityEngine;

namespace AssetBundles
{
    /// <summary>
    /// Simple AssetBundle management.
    /// </summary>
    public partial class AssetBundleManager : IDisposable
    {
        private const string ManifestDownloadKey = "@manifest download key";
        private const string ManifestVersionKey = "@manifest version key";

        private string[] baseUris = default;
        private string platformName = AssetBundleTools.GetPlatformName();
        private PrioritizationStrategy defaultPriority = PrioritizationStrategy.Remote;
        private IDictionary<string, AssetBundleContainer> activeBundles = new Dictionary<string, AssetBundleContainer>(StringComparer.OrdinalIgnoreCase);
        private IDictionary<string, AssetBundleDownloadCallback> downloadCallbacks = new Dictionary<string, AssetBundleDownloadCallback>(StringComparer.OrdinalIgnoreCase);
        private ICommandHandler<AssetBundleDownloadCommand> downloader = default;

        /// <summary>
        /// Returns whether the manager was initialized successfully or not.
        /// </summary>
        public bool Initialized
        {
            get; private set;
        }

        /// <summary>
        /// Returns the object for the platform(entry-point) manifest.
        /// </summary>
        public AssetBundleManifest Manifest
        {
            get; private set;
        }

        /// <summary>
        /// Returns the AssetBundle manifest type.
        ///     None: an error or undefined condition.
        ///     Remote: Download bundles remotely.
        ///     LocalCached: Bundle loaded from local cache.
        ///     StreamingAssets: Bundle loaded from StreamingAssets folder.
        /// </summary>
        public ManifestType ManifestType
        {
            get; private set;
        }

        /// <summary>
        /// Initializes the base-uri used for AssetBundle calls.
        /// The manager will load the manifest file located at base-url/[PlatformName].
        /// </summary>
        /// <param name="uri">base uri</param>
        /// <returns>this</returns>
        public AssetBundleManager Initialize(string uri)
        {
            return Initialize(new[] { uri ?? string.Empty });
        }

        /// <summary>
        /// Initializes a list of base-uris used for AssetBundle calls.
        /// The manager will load the manifest file located at base-url/[PlatformName].
        /// If access to one uri is denied, the manager will try to access the next uri.
        /// </summary>
        /// <param name="uri">List of base-uris</param>
        /// <returns>this</returns>
        public AssetBundleManager Initialize(string[] uris)
        {
            baseUris = new string[uris.Length];

            for (int i = 0; i < uris.Length; i++)
            {
                var builder = new StringBuilder(uris[i]);

                if (uris[i].EndsWith("/") == false)
                    builder.Append("/");

                builder.Append(platformName).Append("/");
                baseUris[i] = builder.ToString();
            }

            return this;
        }

        /// <summary>
        /// Load the platform(entry-point) manifest file.
        /// Downloads the AssetBundle manifest and prepares the system for bundle management.
        /// Uses the platform name as the manifest name.
        /// </summary>
        /// <param name="callback">Called when the loading is complete</param>
        public void Load(Action<bool> callback)
        {
            Load(platformName, true, callback);
        }

        /// <summary>
        /// Load the platform(entry-point) manifest file.
        /// </summary>
        /// <param name="manifestName">The name of the manifest file to download.</param>
        /// <param name="refresh">Always try to download a new manifest even if one has already been cached.</param>
        /// <param name="callback">Called when the loading is complete</param>
        public void Load(string manifestName, bool refresh, Action<bool> callback)
        {
            if (baseUris == null || baseUris.Length == 0)
                throw new Exception("You need to set the base uri before you can initialize.");

            LoadManifest(manifestName, refresh, bundle => callback(bundle != null));
        }

        /// <summary>
        /// Load the platform(entry-point) manifest file.
        /// </summary>
        /// <param name="manifestName">Manifest name</param>
        /// <param name="refresh">Load without using cache or not</param>
        /// <param name="callback">Callback to be called when loading is complete</param>
        private void LoadManifest(string manifestName, bool refresh, Action<AssetBundle> callback)
        {
            if (downloadCallbacks.TryGetValue(ManifestDownloadKey, out var downloadCallback))
            {
                downloadCallback.References++;
                downloadCallback.OnComplete += callback;
                return;
            }

            downloadCallbacks.Add(ManifestDownloadKey, new AssetBundleDownloadCallback(callback));
            ManifestType = ManifestType.Remote;

            uint manifestVersion = 1;

            if (refresh)
            {
                manifestVersion = (uint)PlayerPrefs.GetInt(ManifestVersionKey, 0) + 1;
                while (Caching.IsVersionCached(manifestName, new Hash128(0, 0, 0, manifestVersion)))
                {
                    manifestVersion++;
                }
            }

            LoadManifest(manifestName, manifestVersion, 0);
        }

        /// <summary>
        /// Load the platform(entry-point) manifest file.
        /// </summary>
        /// <param name="manifestName">Manifest name</param>
        /// <param name="version">Local cached version</param>
        /// <param name="index">Index for base-uris</param>
        private void LoadManifest(string manifestName, uint version, int index)
        {
            downloader = new AssetBundleDownloader(baseUris[index]);

            if (Application.isEditor == false)
            {
                downloader = new AssetBundleDownloaderStreamingAsset(
                    manifestName,
                    platformName,
                    downloader,
                    defaultPriority);
            }

            downloader.Handle(new AssetBundleDownloadCommand
            {
                BundleName = manifestName,
                Version = version,
                OnComplete = bundle =>
                {
                    var max = baseUris.Length - 1;
                    if (bundle == null && index < max && version > 1)
                    {
                        Debug.LogFormat($"Unable to download manifest from [{baseUris[index]}], attempting [{baseUris[index + 1]}]");
                        LoadManifest(manifestName, version, index + 1);
                    }
                    else if (bundle == null && index >= max && version > 1 && ManifestType != ManifestType.LocalCached)
                    {
                        ManifestType = ManifestType.LocalCached;
                        Debug.LogFormat($"Unable to download manifest, attempting to use one previously downloaded (version [{version}]).");
                        LoadManifest(manifestName, version - 1, index);
                    }
                    else
                    {
                        OnLoadManifest(bundle, manifestName, version);
                    }
                }
            });
        }

        /// <summary>
        /// Called when the manifest has finished loading, whether successful or not.
        /// </summary>
        /// <param name="manifest">AssetBundle object for the loaded manifest</param>
        /// <param name="manifestName">Name of loaded manifest</param>
        /// <param name="version">Version of loaded manifest</param>
        private void OnLoadManifest(AssetBundle bundle, string manifestName, uint version)
        {
            if (bundle == null)
            {
                Debug.LogError("AssetBundleManifest not found.");

                var streamingAssetsDownloader = downloader as AssetBundleDownloaderStreamingAsset;
                if (streamingAssetsDownloader != null)
                {
                    ManifestType = ManifestType.StreamingAssets;
                    Manifest = streamingAssetsDownloader.Manifest;

                    if (Manifest != null)
                    {
                        Debug.LogWarning("Falling back to streaming assets for bundle information.");
                    }
                }
            }
            else
            {
                Manifest = bundle.LoadAsset<AssetBundleManifest>("assetbundlemanifest");
                PlayerPrefs.SetInt(ManifestVersionKey, (int)version);
                Caching.ClearOtherCachedVersions(manifestName, new Hash128(0, 0, 0, version));
            }

            if (Manifest == null)
            {
                ManifestType = ManifestType.None;
            }
            else
            {
                Initialized = true;
            }

            var callback = downloadCallbacks[ManifestDownloadKey];
            downloadCallbacks.Remove(ManifestDownloadKey);
            callback.OnComplete?.Invoke(bundle);
            bundle?.Unload(false);
        }

        /// <summary>
        /// Downloads an AssetBundle or returns a cached AssetBundle if it has already been downloaded.
        /// Remember to call UnloadBundle for every bundle you download once you are done with it.
        /// </summary>
        /// <param name="bundleName">Name of the bundle to download.</param>
        /// <param name="callback">Action to perform when the bundle has been successfully downloaded.</param>
        public void LoadBundle(string bundleName, Action<AssetBundle> callback)
        {
            if (Initialized == false)
            {
                Debug.LogError("AssetBundleManager must be initialized before you can get a bundle.");
                callback(null);
                return;
            }

            LoadBundle(bundleName, DownloadSettings.UseCacheIfAvailable, callback);
        }

        /// <summary>
        /// Downloads an AssetBundle or returns a cached AssetBundle if it has already been downloaded.
        /// Remember to call UnloadBundle for every bundle you download once you are done with it.
        /// </summary>
        /// <param name="bundleName">Name of the bundle to download.</param>
        /// <param name="callback">Action to perform when the bundle has been successfully downloaded.</param>
        /// <param name="downloadSettings">
        ///     Tell the function to use a previously downloaded version of the bundle if available.
        ///     If the bundle is currently "active" (it has not been unloaded) then the active bundle will be used regardless of this setting.
        ///     If it's important that a new version is downloaded then be sure it isn't active.
        /// </param>
        public void LoadBundle(string bundleName, DownloadSettings downloadSettings, Action<AssetBundle> callback)
        {
            if (Initialized == false)
            {
                Debug.LogError("AssetBundleManager must be initialized before you can get a bundle.");
                callback(null);
                return;
            }

            if (activeBundles.TryGetValue(bundleName, out var activeBundle))
            {
                activeBundle.References++;
                callback(activeBundle.AssetBundle);
                return;
            }

            if (downloadCallbacks.TryGetValue(bundleName, out var downloadCallback))
            {
                downloadCallback.References++;
                downloadCallback.OnComplete += callback;
                return;
            }

            downloadCallbacks.Add(bundleName, new AssetBundleDownloadCallback(callback));

            var mainBundle = new AssetBundleDownloadCommand
            {
                BundleName = bundleName,
                Hash = (downloadSettings == DownloadSettings.UseCacheIfAvailable) ? Manifest.GetAssetBundleHash(bundleName) : default(Hash128),
                OnComplete = bundle => OnLoadBundle(bundle, bundleName)
            };

            var dependencies = Manifest.GetDirectDependencies(bundleName);
            var dependenciesToDownload = new List<string>();

            foreach (var dependency in dependencies)
            {
                if (activeBundles.TryGetValue(dependency, out activeBundle))
                {
                    activeBundle.References++;
                }
                else
                {
                    dependenciesToDownload.Add(dependency);
                }
            }

            if (dependenciesToDownload.Count > 0)
            {
                var dependencyCount = dependenciesToDownload.Count;
                foreach (var dependency in dependenciesToDownload)
                {
                    LoadBundle(dependency, bundle =>
                    {
                        if (--dependencyCount == 0)
                            downloader.Handle(mainBundle);
                    });
                }
            }
            else
            {
                downloader.Handle(mainBundle);
            }
        }

        /// <summary>
        /// Called when the bundle has finished loading, whether successful or not.
        /// </summary>
        /// <param name="bundle">AssetBundle object for the loaded bundle</param>
        /// <param name="bundleName">Name of loaded bundle</param>
        private void OnLoadBundle(AssetBundle bundle, string bundleName)
        {
            var callback = downloadCallbacks[bundleName];
            downloadCallbacks.Remove(bundleName);

            if (activeBundles.TryGetValue(bundleName, out var activeBundle))
            {
                activeBundle.References++;
            }
            else
            {
                activeBundles.Add(bundleName, new AssetBundleContainer
                {
                    AssetBundle = bundle,
                    References = callback.References,
                    Dependencies = Manifest.GetDirectDependencies(bundleName)
                });
            }

            callback.OnComplete?.Invoke(bundle);
        }

        /// <summary>
        /// Unloads an AssetBundle.
        /// Objects that were loaded from this bundle will need to be manually destroyed.
        /// </summary>
        /// <param name="bundle">Bundle to unload.</param>
        public void UnloadBundle(AssetBundle bundle)
        {
            if (bundle == null)
                return;

            UnloadBundle(bundle.name, false, false);
        }

        /// <summary>
        /// Unloads an AssetBundle.
        /// </summary>
        /// <param name="bundle">Bundle to unload.</param>
        /// <param name="unloadAllLoadedObjects">
        ///     When true, all objects that were loaded from this bundle will be destroyed as well.
        ///     If there are game objects in your scene referencing those assets, the references to them will become missing.
        /// </param>
        public void UnloadBundle(AssetBundle bundle, bool unloadAllLoadedObjects)
        {
            if (bundle == null)
                return;

            UnloadBundle(bundle.name, unloadAllLoadedObjects, false);
        }

        /// <summary>
        /// Unloads an AssetBundle.
        /// </summary>
        /// <param name="bundle">Bundle to unload.</param>
        /// <param name="unloadAllLoadedObjects">
        ///     When true, all objects that were loaded from this bundle will be destroyed as well.
        ///     If there are game objects in your scene referencing those assets, the references to them will become missing.
        /// </param>
        /// <param name="force">Unload the bundle even if ABM believes there are other dependencies on it.</param>
        public void UnloadBundle(AssetBundle bundle, bool unloadAllLoadedObjects, bool force)
        {
            if (bundle == null)
                return;

            UnloadBundle(bundle.name, unloadAllLoadedObjects, force);
        }

        /// <summary>
        /// Unloads an AssetBundle and its dependencies if there are no more active references.
        /// </summary>
        private void UnloadBundle(string bundleName, bool unloadAllLoadedObjects, bool force)
        {
            if (activeBundles.TryGetValue(bundleName, out var activeBundle) == false)
                return;

            if (force == true || --activeBundle.References <= 0)
            {
                activeBundle.AssetBundle?.Unload(unloadAllLoadedObjects);
                activeBundles.Remove(bundleName);

                foreach (var dependency in activeBundle.Dependencies)
                    UnloadBundle(dependency, unloadAllLoadedObjects, force);
            }
        }

        /// <summary>
        /// Loading from Unity's StreamingAsset folder.
        /// Sets the base-uri used for AssetBundle calls to the StreamingAssets folder.
        /// </summary>
        public AssetBundleManager UseStreamingAssets()
        {
#if UNITY_ANDROID
            var url = $"{Application.streamingAssetsPath}/{AssetBundleTools.AssetFolder}/";
#else
            var url = $"file:///{Application.streamingAssetsPath}/{AssetBundleTools.AssetFolder}/";
#endif
            return Initialize(new[] { url });
        }

        /// <summary>
        /// Loading from the Simulation folder.
        /// Sets the base-uri used for AssetBundle calls to the one created by the AssetBundleBuilder when the bundles are built.
        /// Used for easier testing in the editor.
        /// </summary>
        public AssetBundleManager UseSimulation()
        {
            return Initialize(new[] { $"file://{Application.dataPath}/../{AssetBundleTools.AssetFolder}/" });
        }

        /// <summary>
        /// Changes the strategy used to determine what should happen when an asset bundle exists in both the StreamingAssets and the remote server.
        /// The default is to prioritize the remote asset over the StreamingAssets folder
        /// </summary>
        /// <param name="unloadAllLoadedObjects">
        ///     Remote:
        ///     StreamingAssets:
        /// </param>
        public AssetBundleManager SetPrioritizationStrategy(PrioritizationStrategy strategy)
        {
            defaultPriority = strategy;
            return this;
        }

        /// <summary>
        /// Check to see if a specific asset bundle is cached or needs to be downloaded.
        /// </summary>
        public bool IsVersionCached(string bundleName)
        {
            if (Manifest == null)
                return false;

            if (string.IsNullOrEmpty(bundleName))
                return false;

            // TODO: need to check it out!
            return Caching.IsVersionCached(bundleName, Manifest.GetAssetBundleHash(bundleName));
        }

        /// <summary>
        /// Cleans up all downloaded bundles.
        /// </summary>
        public void Dispose()
        {
            foreach (var cache in activeBundles.Values)
                cache.AssetBundle?.Unload(true);

            activeBundles.Clear();
        }
    }
}
