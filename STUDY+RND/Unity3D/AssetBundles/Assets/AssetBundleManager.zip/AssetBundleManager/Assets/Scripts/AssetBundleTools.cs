﻿#if UNITY_EDITOR
using UnityEditor;
#endif
using System.IO;
using UnityEngine;

namespace AssetBundles
{
    public static class AssetBundleTools
    {
        public const string AssetFolder = "AssetBundles";

#if UNITY_EDITOR
        [MenuItem("AssetBundle/Build/Android", priority = 1)]
        public static void BuildAndroid()
        {
            Build(BuildTarget.Android);
        }

        [MenuItem("AssetBundle/Build/Windows", priority = 2)]
        public static void BuildWindows()
        {
            Build(BuildTarget.StandaloneWindows64);
        }

        [MenuItem("AssetBundle/Build/iOS", priority = 3)]
        public static void BuildIOS()
        {
            Build(BuildTarget.iOS);
        }

        [MenuItem("AssetBundle/Build/All", priority = 4)]
        public static void BuildAll()
        {
            BuildAndroid();
            BuildWindows();
            BuildIOS();
        }

        [MenuItem("AssetBundle/Show Bundle Reference", priority = 5)]
        public static void BundleList()
        {
            foreach (var bundle in AssetDatabase.GetAllAssetBundleNames())
            {
                foreach (var asset in AssetDatabase.GetAssetPathsFromAssetBundle(bundle))
                {
                    Debug.Log($"{bundle} / {asset}");
                }
            }
        }

        [MenuItem("AssetBundle/Copy To StreamingAssets", priority = 6)]
        public static void CopyToStreamingAssets()
        {
            var streaming = Path.Combine(Application.streamingAssetsPath, AssetFolder);
            ClearPath(streaming);
            CopyPath(AssetFolder, streaming);
            AssetDatabase.Refresh();
        }

        public static void Build(BuildTarget buildTarget)
        {
            var output = Path.Combine(AssetFolder, GetPlatformName(buildTarget));
            ClearPath(output);
            BuildPipeline.BuildAssetBundles(output, BuildAssetBundleOptions.None, buildTarget);
        }
#endif

        public static string GetPlatformName()
        {
#if UNITY_EDITOR
            return GetPlatformName(EditorUserBuildSettings.activeBuildTarget);
#else
			return GetPlatformName(Application.platform);
#endif
        }

#if UNITY_EDITOR
        public static string GetPlatformName(BuildTarget target)
        {
            switch (target)
            {
                case BuildTarget.Android:
                    return "Android";
                case BuildTarget.iOS:
                    return "iOS";
                case BuildTarget.tvOS:
                    return "tvOS";
                case BuildTarget.WebGL:
                    return "WebGL";
                case BuildTarget.StandaloneWindows:
                case BuildTarget.StandaloneWindows64:
                    return "StandaloneWindows";
                case BuildTarget.StandaloneOSX:
                    return "StandaloneOSX";
                case BuildTarget.StandaloneLinux64:
                    return "StandaloneLinux";
                case BuildTarget.Switch:
                    return "Switch";
                default:
                    Debug.Log($"Unknown BuildTarget: Using Default Enum Name: {target}");
                    return target.ToString();
            }
        }
#endif

        public static string GetPlatformName(RuntimePlatform platform)
        {
            switch (platform)
            {
                case RuntimePlatform.Android:
                    return "Android";
                case RuntimePlatform.IPhonePlayer:
                    return "iOS";
                case RuntimePlatform.tvOS:
                    return "tvOS";
                case RuntimePlatform.WebGLPlayer:
                    return "WebGL";
                case RuntimePlatform.WindowsPlayer:
                    return "StandaloneWindows";
                case RuntimePlatform.OSXPlayer:
                    return "StandaloneOSX";
                case RuntimePlatform.LinuxPlayer:
                    return "StandaloneLinux";
                case RuntimePlatform.Switch:
                    return "Switch";
                default:
                    Debug.Log($"Unknown BuildTarget: Using Default Enum Name: {platform}");
                    return platform.ToString();
            }
        }

        public static void CopyPath(string source, string target)
        {
            if (Directory.Exists(target) == false)
                Directory.CreateDirectory(target);

            var files = Directory.GetFiles(source);
            var directories = Directory.GetDirectories(source);

            foreach (var file in files)
            {
                File.Copy(file, Path.Combine(target, Path.GetFileName(file)));
            }

            foreach (var directory in directories)
            {
                CopyPath(directory, Path.Combine(target, Path.GetFileName(directory)));
            }
        }

        public static void ClearPath(string path)
        {
            if (Directory.Exists(path))
            {
                var dirInfo = new DirectoryInfo(path);

                foreach (var file in dirInfo.GetFiles())
                    file.Delete();

                foreach (var dir in dirInfo.GetDirectories())
                    dir.Delete(true);
            }
            else
            {
                Directory.CreateDirectory(path);
            }
        }
    }
}
