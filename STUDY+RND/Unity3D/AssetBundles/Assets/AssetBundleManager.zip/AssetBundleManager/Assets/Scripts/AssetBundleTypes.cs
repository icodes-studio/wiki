﻿using System;
using UnityEngine;

namespace AssetBundles
{
    public enum DownloadSettings
    {
        UseCacheIfAvailable,
        DoNotUseCache
    }

    public enum PrioritizationStrategy
    {
        Remote,
        StreamingAssets,
    }

    public enum ManifestType
    {
        None,
        Remote,
        LocalCached,
        StreamingAssets,
    }

    interface ICommandHandler<in T>
    {
        void Handle(T command);
    }

    class AssetBundleDownloadCommand
    {
        public string BundleName;
        public uint Version;
        public Hash128 Hash;
        public Action<AssetBundle> OnComplete;
    }

    class AssetBundleContainer
    {
        public AssetBundle AssetBundle = null;
        public string[] Dependencies = null;
        public int References = 1;
    }

    class AssetBundleDownloadCallback
    {
        public int References;
        public Action<AssetBundle> OnComplete;
        public AssetBundleDownloadCallback(Action<AssetBundle> callback)
        {
            References = 1;
            OnComplete = callback;
        }
    }
}
